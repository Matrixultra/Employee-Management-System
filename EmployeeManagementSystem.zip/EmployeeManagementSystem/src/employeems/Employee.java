package employeems;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Employee class representing an employee entity.
 * Implements Serializable for file persistence.
 */
public class Employee implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String name;
    private String department;
    private String position;
    private double salary;
    private Date joinDate;

    // Constructor
    public Employee(String id, String name, String department, String position, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.position = position;
        this.salary = salary;
        this.joinDate = new Date(); // Current date/time
    }

    // Constructor with custom join date
    public Employee(String id, String name, String department, String position, double salary, Date joinDate) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.position = position;
        this.salary = salary;
        this.joinDate = joinDate;
    }

    // ---------- Getters ----------
    public String getId()         { return id; }
    public String getName()       { return name; }
    public String getDepartment() { return department; }
    public String getPosition()   { return position; }
    public double getSalary()     { return salary; }
    public Date   getJoinDate()   { return joinDate; }

    // ---------- Setters ----------
    public void setId(String id)               { this.id = id; }
    public void setName(String name)           { this.name = name; }
    public void setDepartment(String dept)     { this.department = dept; }
    public void setPosition(String position)   { this.position = position; }
    public void setSalary(double salary)       { this.salary = salary; }
    public void setJoinDate(Date joinDate)     { this.joinDate = joinDate; }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return String.format(
            "ID: %-8s | Name: %-20s | Dept: %-15s | Position: %-20s | Salary: Rs.%-10.2f | Joined: %s",
            id, name, department, position, salary, sdf.format(joinDate)
        );
    }
}
