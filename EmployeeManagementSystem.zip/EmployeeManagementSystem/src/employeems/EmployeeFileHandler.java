package employeems;

import java.io.*;
import java.util.ArrayList;

/**
 * EmployeeFileHandler handles all file I/O operations.
 * Saves and loads employee data using Java Object Serialization.
 */
public class EmployeeFileHandler {

    private static final String DATA_FILE = "data/employees.dat";

    /**
     * Saves the list of employees to a .dat file using ObjectOutputStream.
     *
     * @param employees ArrayList of Employee objects to save
     */
    public void saveEmployees(ArrayList<Employee> employees) {
        // Ensure data directory exists
        File dir = new File("data");
        if (!dir.exists()) {
            dir.mkdirs();
        }

        try (ObjectOutputStream oos = new ObjectOutputStream(
                new BufferedOutputStream(new FileOutputStream(DATA_FILE)))) {
            oos.writeObject(employees);
            System.out.println("  [OK] Data saved successfully to '" + DATA_FILE + "'.");
        } catch (IOException e) {
            System.out.println("  [ERROR] Could not save data: " + e.getMessage());
        }
    }

    /**
     * Loads employees from the .dat file using ObjectInputStream.
     *
     * @return ArrayList of Employee objects, or empty list if file not found
     */
    @SuppressWarnings("unchecked")
    public ArrayList<Employee> loadEmployees() {
        File file = new File(DATA_FILE);

        if (!file.exists()) {
            System.out.println("  [INFO] No saved data found. Starting with empty list.");
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(
                new BufferedInputStream(new FileInputStream(DATA_FILE)))) {
            ArrayList<Employee> employees = (ArrayList<Employee>) ois.readObject();
            System.out.println("  [OK] Loaded " + employees.size() + " employee(s) from file.");
            return employees;
        } catch (FileNotFoundException e) {
            System.out.println("  [ERROR] Data file not found: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("  [ERROR] Error reading data file: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("  [ERROR] Data file is corrupted or incompatible: " + e.getMessage());
        }

        return new ArrayList<>();
    }

    /**
     * Exports all employees to a human-readable text report.
     *
     * @param employees ArrayList of Employee objects
     * @param filename  The output filename (inside reports/ folder)
     */
    public void exportToTextFile(ArrayList<Employee> employees, String filename) {
        File dir = new File("reports");
        if (!dir.exists()) {
            dir.mkdirs();
        }

        String path = "reports/" + filename;
        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(path)))) {
            pw.println("========================================");
            pw.println("       EMPLOYEE MANAGEMENT SYSTEM       ");
            pw.println("          FULL EMPLOYEE REPORT          ");
            pw.println("========================================");
            pw.println("Total Employees: " + employees.size());
            pw.println("----------------------------------------");

            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
            for (Employee emp : employees) {
                pw.printf("ID       : %s%n", emp.getId());
                pw.printf("Name     : %s%n", emp.getName());
                pw.printf("Dept     : %s%n", emp.getDepartment());
                pw.printf("Position : %s%n", emp.getPosition());
                pw.printf("Salary   : Rs.%.2f%n", emp.getSalary());
                pw.printf("Joined   : %s%n", sdf.format(emp.getJoinDate()));
                pw.println("----------------------------------------");
            }

            System.out.println("  [OK] Report exported to '" + path + "'.");
        } catch (IOException e) {
            System.out.println("  [ERROR] Could not write report: " + e.getMessage());
        }
    }
}
