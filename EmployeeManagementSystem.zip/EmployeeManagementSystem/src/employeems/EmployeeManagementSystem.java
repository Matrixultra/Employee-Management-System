package employeems;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * EmployeeManagementSystem is the core class.
 * It manages the in-memory collections (ArrayList + HashMap),
 * and provides all CRUD, search, and reporting operations.
 */
public class EmployeeManagementSystem {

    // ---- Collections ----
    private ArrayList<Employee> employees;        // Ordered list for iteration
    private HashMap<String, Employee> employeeMap; // Fast O(1) lookup by ID

    // ---- Helper classes ----
    private EmployeeFileHandler    fileHandler;
    private EmployeeReportGenerator reportGen;
    private Scanner scanner;

    private static final String DIVIDER = "=".repeat(60);
    private static final String LINE    = "-".repeat(60);

    // ================================================================
    //  Constructor
    // ================================================================
    public EmployeeManagementSystem() {
        employees    = new ArrayList<>();
        employeeMap  = new HashMap<>();
        fileHandler  = new EmployeeFileHandler();
        reportGen    = new EmployeeReportGenerator();
        scanner      = new Scanner(System.in);

        // Auto-load on startup
        loadFromFile();
    }

    // ================================================================
    //  MAIN MENU
    // ================================================================
    public void run() {
        System.out.println("\n" + DIVIDER);
        System.out.println("     WELCOME TO EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println(DIVIDER);

        boolean running = true;
        while (running) {
            printMenu();
            int choice = getValidInt(1, 10);

            switch (choice) {
                case 1:  addEmployee();       break;
                case 2:  viewAllEmployees();  break;
                case 3:  searchEmployee();    break;
                case 4:  updateEmployee();    break;
                case 5:  deleteEmployee();    break;
                case 6:  generateReports();   break;
                case 7:  saveToFile();        break;
                case 8:  loadFromFile();      break;
                case 9:  exportReport();      break;
                case 10: running = exit();    break;
            }
        }
    }

    private void printMenu() {
        System.out.println("\n" + DIVIDER);
        System.out.println("         EMPLOYEE MANAGEMENT SYSTEM");
        System.out.println(DIVIDER);
        System.out.println("  1.  Add New Employee");
        System.out.println("  2.  View All Employees");
        System.out.println("  3.  Search Employee");
        System.out.println("  4.  Update Employee");
        System.out.println("  5.  Delete Employee");
        System.out.println("  6.  Generate Reports");
        System.out.println("  7.  Save to File");
        System.out.println("  8.  Load from File");
        System.out.println("  9.  Export Report to Text File");
        System.out.println("  10. Exit");
        System.out.println(LINE);
        System.out.print("  Enter your choice (1-10): ");
    }

    // ================================================================
    //  1. ADD EMPLOYEE  (Create)
    // ================================================================
    public void addEmployee() {
        System.out.println("\n" + DIVIDER);
        System.out.println("         ADD NEW EMPLOYEE");
        System.out.println(DIVIDER);

        // -- Employee ID --
        String id;
        while (true) {
            System.out.print("  Enter Employee ID (e.g. E001): ");
            id = scanner.nextLine().trim().toUpperCase();
            if (id.isEmpty()) {
                System.out.println("  [!] ID cannot be empty.");
            } else if (employeeMap.containsKey(id)) {
                System.out.println("  [!] Employee with ID '" + id + "' already exists!");
            } else {
                break;
            }
        }

        // -- Name --
        String name;
        while (true) {
            System.out.print("  Enter Name: ");
            name = scanner.nextLine().trim();
            if (!name.isEmpty()) break;
            System.out.println("  [!] Name cannot be empty.");
        }

        // -- Department --
        String department;
        while (true) {
            System.out.print("  Enter Department: ");
            department = scanner.nextLine().trim();
            if (!department.isEmpty()) break;
            System.out.println("  [!] Department cannot be empty.");
        }

        // -- Position --
        String position;
        while (true) {
            System.out.print("  Enter Position: ");
            position = scanner.nextLine().trim();
            if (!position.isEmpty()) break;
            System.out.println("  [!] Position cannot be empty.");
        }

        // -- Salary --
        double salary = getValidSalary("  Enter Salary (Rs.): ");

        // -- Join Date --
        Date joinDate = getValidDate("  Enter Join Date (yyyy-MM-dd) [press Enter for today]: ", true);

        // Build and store
        Employee emp = (joinDate != null)
                ? new Employee(id, name, department, position, salary, joinDate)
                : new Employee(id, name, department, position, salary);

        employees.add(emp);
        employeeMap.put(id, emp);

        System.out.println("\n  [OK] Employee added successfully!");
        System.out.println("  " + emp);

        saveToFile(); // Auto-save
    }

    // ================================================================
    //  2. VIEW ALL EMPLOYEES  (Read)
    // ================================================================
    public void viewAllEmployees() {
        System.out.println("\n" + DIVIDER);
        System.out.println("         ALL EMPLOYEES  (" + employees.size() + " total)");
        System.out.println(DIVIDER);

        if (employees.isEmpty()) {
            System.out.println("  No employees found. Add some first!");
            return;
        }

        printEmployeeTableHeader();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        int i = 1;
        for (Employee emp : employees) {
            String salaryStr = String.format("Rs.%,.2f", emp.getSalary());
            System.out.printf("  %-4d %-8s %-20s %-15s %-18s %-16s %-12s%n",
                    i++,
                    emp.getId(),
                    truncate(emp.getName(), 20),
                    truncate(emp.getDepartment(), 15),
                    truncate(emp.getPosition(), 18),
                    salaryStr,
                    sdf.format(emp.getJoinDate()));
        }
        System.out.println("  " + "-".repeat(100));
    }

    private void printEmployeeTableHeader() {
        System.out.printf("  %-4s %-8s %-20s %-15s %-18s %-16s %-12s%n",
                "#", "ID", "Name", "Department", "Position", "Salary", "Join Date");
        System.out.println("  " + "-".repeat(100));
    }

    // ================================================================
    //  3. SEARCH EMPLOYEE
    // ================================================================
    public void searchEmployee() {
        System.out.println("\n" + DIVIDER);
        System.out.println("         SEARCH EMPLOYEE");
        System.out.println(DIVIDER);
        System.out.println("  1. Search by ID");
        System.out.println("  2. Search by Name");
        System.out.println("  3. Search by Department");
        System.out.println("  4. Search by Position");
        System.out.println("  5. Search by Salary Range");
        System.out.print("  Enter choice (1-5): ");

        int choice = getValidInt(1, 5);

        switch (choice) {
            case 1: searchById();          break;
            case 2: searchByName();        break;
            case 3: searchByDepartment();  break;
            case 4: searchByPosition();    break;
            case 5: searchBySalaryRange(); break;
        }
    }

    private void searchById() {
        System.out.print("  Enter Employee ID: ");
        String id = scanner.nextLine().trim().toUpperCase();

        Employee emp = employeeMap.get(id); // O(1) HashMap lookup
        if (emp != null) {
            System.out.println("\n  Employee found:");
            System.out.println("  " + emp);
        } else {
            System.out.println("  [!] No employee found with ID '" + id + "'.");
        }
    }

    private void searchByName() {
        System.out.print("  Enter name (or partial name): ");
        String keyword = scanner.nextLine().trim().toLowerCase();

        List<Employee> results = new ArrayList<>();
        for (Employee emp : employees) {
            if (emp.getName().toLowerCase().contains(keyword)) {
                results.add(emp);
            }
        }
        printSearchResults(results, "name", keyword);
    }

    private void searchByDepartment() {
        System.out.print("  Enter department: ");
        String keyword = scanner.nextLine().trim().toLowerCase();

        List<Employee> results = new ArrayList<>();
        for (Employee emp : employees) {
            if (emp.getDepartment().toLowerCase().contains(keyword)) {
                results.add(emp);
            }
        }
        printSearchResults(results, "department", keyword);
    }

    private void searchByPosition() {
        System.out.print("  Enter position: ");
        String keyword = scanner.nextLine().trim().toLowerCase();

        List<Employee> results = new ArrayList<>();
        for (Employee emp : employees) {
            if (emp.getPosition().toLowerCase().contains(keyword)) {
                results.add(emp);
            }
        }
        printSearchResults(results, "position", keyword);
    }

    private void searchBySalaryRange() {
        double min = getValidSalary("  Enter minimum salary (Rs.): ");
        double max = getValidSalary("  Enter maximum salary (Rs.): ");

        if (min > max) {
            System.out.println("  [!] Minimum salary cannot exceed maximum.");
            return;
        }

        List<Employee> results = new ArrayList<>();
        for (Employee emp : employees) {
            if (emp.getSalary() >= min && emp.getSalary() <= max) {
                results.add(emp);
            }
        }
        printSearchResults(results, "salary range", String.format("Rs.%.2f - Rs.%.2f", min, max));
    }

    private void printSearchResults(List<Employee> results, String field, String keyword) {
        System.out.println("\n  Search Results for " + field + " = '" + keyword + "':");
        System.out.println("  Found " + results.size() + " employee(s).");
        System.out.println("  " + LINE);
        if (results.isEmpty()) return;

        printEmployeeTableHeader();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        int i = 1;
        for (Employee emp : results) {
            String salaryStr = String.format("Rs.%,.2f", emp.getSalary());
            System.out.printf("  %-4d %-8s %-20s %-15s %-18s %-16s %-12s%n",
                    i++, emp.getId(), truncate(emp.getName(), 20),
                    truncate(emp.getDepartment(), 15), truncate(emp.getPosition(), 18),
                    salaryStr, sdf.format(emp.getJoinDate()));
        }
        System.out.println("  " + "-".repeat(100));
    }

    // ================================================================
    //  4. UPDATE EMPLOYEE
    // ================================================================
    public void updateEmployee() {
        System.out.println("\n" + DIVIDER);
        System.out.println("         UPDATE EMPLOYEE");
        System.out.println(DIVIDER);
        System.out.print("  Enter Employee ID to update: ");
        String id = scanner.nextLine().trim().toUpperCase();

        Employee emp = employeeMap.get(id);
        if (emp == null) {
            System.out.println("  [!] Employee with ID '" + id + "' not found.");
            return;
        }

        System.out.println("\n  Current details: " + emp);
        System.out.println("\n  What would you like to update?");
        System.out.println("  1. Name");
        System.out.println("  2. Department");
        System.out.println("  3. Position");
        System.out.println("  4. Salary");
        System.out.println("  5. All fields");
        System.out.println("  6. Cancel");
        System.out.print("  Enter choice (1-6): ");

        int choice = getValidInt(1, 6);

        if (choice == 6) {
            System.out.println("  Update cancelled.");
            return;
        }

        switch (choice) {
            case 1:
                System.out.print("  New Name [" + emp.getName() + "]: ");
                String newName = scanner.nextLine().trim();
                if (!newName.isEmpty()) emp.setName(newName);
                break;
            case 2:
                System.out.print("  New Department [" + emp.getDepartment() + "]: ");
                String newDept = scanner.nextLine().trim();
                if (!newDept.isEmpty()) emp.setDepartment(newDept);
                break;
            case 3:
                System.out.print("  New Position [" + emp.getPosition() + "]: ");
                String newPos = scanner.nextLine().trim();
                if (!newPos.isEmpty()) emp.setPosition(newPos);
                break;
            case 4:
                double newSalary = getValidSalary("  New Salary (Rs.) [" + emp.getSalary() + "]: ");
                emp.setSalary(newSalary);
                break;
            case 5:
                System.out.print("  New Name [" + emp.getName() + "]: ");
                String n = scanner.nextLine().trim();
                if (!n.isEmpty()) emp.setName(n);

                System.out.print("  New Department [" + emp.getDepartment() + "]: ");
                String d = scanner.nextLine().trim();
                if (!d.isEmpty()) emp.setDepartment(d);

                System.out.print("  New Position [" + emp.getPosition() + "]: ");
                String p = scanner.nextLine().trim();
                if (!p.isEmpty()) emp.setPosition(p);

                double s = getValidSalary("  New Salary (Rs.) [" + emp.getSalary() + "]: ");
                emp.setSalary(s);
                break;
        }

        System.out.println("\n  [OK] Employee updated successfully!");
        System.out.println("  Updated: " + emp);
        saveToFile();
    }

    // ================================================================
    //  5. DELETE EMPLOYEE
    // ================================================================
    public void deleteEmployee() {
        System.out.println("\n" + DIVIDER);
        System.out.println("         DELETE EMPLOYEE");
        System.out.println(DIVIDER);
        System.out.print("  Enter Employee ID to delete: ");
        String id = scanner.nextLine().trim().toUpperCase();

        Employee emp = employeeMap.get(id);
        if (emp == null) {
            System.out.println("  [!] Employee with ID '" + id + "' not found.");
            return;
        }

        System.out.println("\n  Employee to delete: " + emp);
        System.out.print("  Are you sure you want to delete this employee? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();

        if (confirm.equals("yes") || confirm.equals("y")) {
            employees.remove(emp);
            employeeMap.remove(id);
            System.out.println("  [OK] Employee '" + emp.getName() + "' deleted successfully.");
            saveToFile();
        } else {
            System.out.println("  Deletion cancelled.");
        }
    }

    // ================================================================
    //  6. GENERATE REPORTS
    // ================================================================
    public void generateReports() {
        System.out.println("\n" + DIVIDER);
        System.out.println("         GENERATE REPORTS");
        System.out.println(DIVIDER);
        System.out.println("  1. Salary Statistics");
        System.out.println("  2. Department-wise Summary");
        System.out.println("  3. Position-wise Employee Count");
        System.out.println("  4. Employees Ranked by Salary");
        System.out.println("  5. Recently Joined Employees");
        System.out.println("  6. Full Report (all of the above)");
        System.out.print("  Enter choice (1-6): ");

        int choice = getValidInt(1, 6);

        switch (choice) {
            case 1: reportGen.salaryStatistics(employees);    break;
            case 2: reportGen.departmentSummary(employees);   break;
            case 3: reportGen.positionSummary(employees);     break;
            case 4: reportGen.employeesBySalary(employees);   break;
            case 5:
                System.out.print("  Show top how many? (e.g. 5): ");
                int n = getValidInt(1, employees.size() > 0 ? employees.size() : 1);
                reportGen.recentJoinees(employees, n);
                break;
            case 6:
                reportGen.salaryStatistics(employees);
                reportGen.departmentSummary(employees);
                reportGen.positionSummary(employees);
                reportGen.employeesBySalary(employees);
                reportGen.recentJoinees(employees, 5);
                break;
        }
    }

    // ================================================================
    //  7. SAVE TO FILE
    // ================================================================
    public void saveToFile() {
        fileHandler.saveEmployees(employees);
    }

    // ================================================================
    //  8. LOAD FROM FILE
    // ================================================================
    public void loadFromFile() {
        employees = fileHandler.loadEmployees();
        // Rebuild HashMap from loaded list
        employeeMap.clear();
        for (Employee emp : employees) {
            employeeMap.put(emp.getId(), emp);
        }
    }

    // ================================================================
    //  9. EXPORT TEXT REPORT
    // ================================================================
    public void exportReport() {
        String filename = "employee_report_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".txt";
        fileHandler.exportToTextFile(employees, filename);
    }

    // ================================================================
    //  10. EXIT
    // ================================================================
    private boolean exit() {
        System.out.print("\n  Save data before exiting? (yes/no): ");
        String ans = scanner.nextLine().trim().toLowerCase();
        if (ans.equals("yes") || ans.equals("y")) {
            saveToFile();
        }
        System.out.println("\n  Thank you for using Employee Management System. Goodbye!");
        return false; // signals loop to stop
    }

    // ================================================================
    //  UTILITY METHODS
    // ================================================================

    /** Reads a valid integer in [min, max] from stdin (reads full line). */
    private int getValidInt(int min, int max) {
        while (true) {
            try {
                String line = scanner.nextLine().trim();
                int val = Integer.parseInt(line);
                if (val >= min && val <= max) return val;
                System.out.printf("  [!] Please enter a number between %d and %d: ", min, max);
            } catch (NumberFormatException e) {
                System.out.print("  [!] Invalid input. Enter a number: ");
            }
        }
    }

    /** Reads a valid non-negative double salary. */
    private double getValidSalary(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double val = Double.parseDouble(scanner.nextLine().trim());
                if (val >= 0) return val;
                System.out.println("  [!] Salary cannot be negative.");
            } catch (NumberFormatException e) {
                System.out.println("  [!] Invalid number. Try again.");
            }
        }
    }

    /**
     * Reads a valid date string. If optional=true and user presses Enter, returns null.
     */
    private Date getValidDate(String prompt, boolean optional) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false);
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (optional && input.isEmpty()) return null;
            try {
                return sdf.parse(input);
            } catch (ParseException e) {
                System.out.println("  [!] Invalid date format. Use yyyy-MM-dd (e.g. 2024-01-15).");
            }
        }
    }

    /** Truncates a string to maxLen characters. */
    private String truncate(String str, int maxLen) {
        if (str == null) return "";
        return str.length() <= maxLen ? str : str.substring(0, maxLen - 1) + ".";
    }
}
