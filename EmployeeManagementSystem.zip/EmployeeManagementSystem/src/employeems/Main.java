package employeems;

/**
 * Main.java — Entry point for the Employee Management System.
 *
 * To compile and run (from the EmployeeManagementSystem folder):
 *   javac -d out src/employeems/*.java
 *   java -cp out employeems.Main
 */
public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem();
        ems.run();
    }
}
