package employeems;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * EmployeeReportGenerator generates statistical and summary reports
 * from the current employee list.
 */
public class EmployeeReportGenerator {

    private static final String LINE = "-".repeat(80);

    /**
     * Displays salary statistics: total, average, min, max.
     */
    public void salaryStatistics(ArrayList<Employee> employees) {
        if (employees.isEmpty()) {
            System.out.println("  No employees to report on.");
            return;
        }

        double total = 0;
        double highest = Double.MIN_VALUE;
        double lowest = Double.MAX_VALUE;
        Employee highEmp = null, lowEmp = null;

        for (Employee emp : employees) {
            double s = emp.getSalary();
            total += s;
            if (s > highest) { highest = s; highEmp = emp; }
            if (s < lowest)  { lowest = s;  lowEmp  = emp; }
        }

        double average = total / employees.size();

        System.out.println("\n  SALARY STATISTICS");
        System.out.println("  " + LINE);
        System.out.printf("  Total Employees  : %d%n", employees.size());
        System.out.printf("  Total Salary     : Rs.%,.2f%n", total);
        System.out.printf("  Average Salary   : Rs.%,.2f%n", average);
        System.out.printf("  Highest Salary   : Rs.%,.2f  (%s)%n", highest,
                highEmp != null ? highEmp.getName() : "N/A");
        System.out.printf("  Lowest Salary    : Rs.%,.2f  (%s)%n", lowest,
                lowEmp != null ? lowEmp.getName() : "N/A");
        System.out.println("  " + LINE);
    }

    /**
     * Displays department-wise summary with count and average salary.
     */
    public void departmentSummary(ArrayList<Employee> employees) {
        if (employees.isEmpty()) {
            System.out.println("  No employees to report on.");
            return;
        }

        // Map: Department -> [totalSalary, count]
        Map<String, double[]> deptMap = new TreeMap<>();

        for (Employee emp : employees) {
            String dept = emp.getDepartment();
            deptMap.putIfAbsent(dept, new double[]{0, 0});
            deptMap.get(dept)[0] += emp.getSalary();
            deptMap.get(dept)[1]++;
        }

        System.out.println("\n  DEPARTMENT-WISE SUMMARY");
        System.out.println("  " + LINE);
        System.out.printf("  %-20s %-12s %-16s %-16s%n",
                "Department", "Employees", "Total Salary", "Avg Salary");
        System.out.println("  " + LINE);

        for (Map.Entry<String, double[]> entry : deptMap.entrySet()) {
            String dept    = entry.getKey();
            double total   = entry.getValue()[0];
            int    count   = (int) entry.getValue()[1];
            double avg     = total / count;
            String tStr = String.format("Rs.%,.2f", total);
            String aStr = String.format("Rs.%,.2f", avg);
            System.out.printf("  %-20s %-12d %-16s %-16s%n",
                    dept, count, tStr, aStr);
        }
        System.out.println("  " + LINE);
    }

    /**
     * Displays employee count grouped by position.
     */
    public void positionSummary(ArrayList<Employee> employees) {
        if (employees.isEmpty()) {
            System.out.println("  No employees to report on.");
            return;
        }

        Map<String, Integer> posMap = new TreeMap<>();
        for (Employee emp : employees) {
            posMap.merge(emp.getPosition(), 1, Integer::sum);
        }

        System.out.println("\n  POSITION-WISE EMPLOYEE COUNT");
        System.out.println("  " + LINE);
        System.out.printf("  %-30s %-10s%n", "Position", "Count");
        System.out.println("  " + LINE);
        for (Map.Entry<String, Integer> entry : posMap.entrySet()) {
            System.out.printf("  %-30s %-10d%n", entry.getKey(), entry.getValue());
        }
        System.out.println("  " + LINE);
    }

    /**
     * Lists employees sorted by salary (descending).
     */
    public void employeesBySalary(ArrayList<Employee> employees) {
        if (employees.isEmpty()) {
            System.out.println("  No employees to report on.");
            return;
        }

        List<Employee> sorted = new ArrayList<>(employees);
        sorted.sort((a, b) -> Double.compare(b.getSalary(), a.getSalary()));

        System.out.println("\n  EMPLOYEES RANKED BY SALARY (Highest to Lowest)");
        System.out.println("  " + LINE);
        System.out.printf("  %-5s %-10s %-20s %-15s %-16s%n",
                "Rank", "ID", "Name", "Department", "Salary");
        System.out.println("  " + LINE);

        int rank = 1;
        for (Employee emp : sorted) {
            String sStr = String.format("Rs.%,.2f", emp.getSalary());
            System.out.printf("  %-5d %-10s %-20s %-15s %-16s%n",
                    rank++, emp.getId(), emp.getName(),
                    emp.getDepartment(), sStr);
        }
        System.out.println("  " + LINE);
    }

    /**
     * Lists recently joined employees (sorted by join date descending).
     */
    public void recentJoinees(ArrayList<Employee> employees, int topN) {
        if (employees.isEmpty()) {
            System.out.println("  No employees to report on.");
            return;
        }

        List<Employee> sorted = new ArrayList<>(employees);
        sorted.sort((a, b) -> b.getJoinDate().compareTo(a.getJoinDate()));

        int limit = Math.min(topN, sorted.size());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        System.out.println("\n  MOST RECENTLY JOINED EMPLOYEES (Top " + limit + ")");
        System.out.println("  " + LINE);
        System.out.printf("  %-10s %-20s %-15s %-20s %-12s%n",
                "ID", "Name", "Department", "Position", "Join Date");
        System.out.println("  " + LINE);

        for (int i = 0; i < limit; i++) {
            Employee emp = sorted.get(i);
            System.out.printf("  %-10s %-20s %-15s %-20s %-12s%n",
                    emp.getId(), emp.getName(), emp.getDepartment(),
                    emp.getPosition(), sdf.format(emp.getJoinDate()));
        }
        System.out.println("  " + LINE);
    }
}
