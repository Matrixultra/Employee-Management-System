# Data Format Specification

## Binary Data File (employees.dat)

**Location:** `data/employees.dat`
**Format:** Java Object Serialization (binary)
**Created by:** `EmployeeFileHandler.saveEmployees()`
**Read by:** `EmployeeFileHandler.loadEmployees()`

### How it works
The entire `ArrayList<Employee>` is written as a single object using Java's built-in serialization. The `Employee` class implements `java.io.Serializable` with `serialVersionUID = 1L` to ensure compatibility.

```
ObjectOutputStream → FileOutputStream → employees.dat
ObjectInputStream  ← FileInputStream  ← employees.dat
```

### Employee Fields Stored
| Field      | Java Type | Example              |
|------------|-----------|----------------------|
| id         | String    | "E001"               |
| name       | String    | "Alice Johnson"      |
| department | String    | "Engineering"        |
| position   | String    | "Software Developer" |
| salary     | double    | 85000.00             |
| joinDate   | Date      | 2024-01-15           |

---

## Text Export File (reports/*.txt)

**Location:** `reports/employee_report_YYYYMMDD_HHmmss.txt`
**Format:** Human-readable plain text
**Created by:** `EmployeeFileHandler.exportToTextFile()`

### Sample exported file
```
========================================
       EMPLOYEE MANAGEMENT SYSTEM
          FULL EMPLOYEE REPORT
========================================
Total Employees: 4
----------------------------------------
ID       : E001
Name     : Alice Johnson
Dept     : Engineering
Position : Software Developer
Salary   : Rs.85000.00
Joined   : 2024-01-15
----------------------------------------
```

---

## Employee ID Convention
Employee IDs follow the format `E` followed by 3 digits (e.g. `E001`, `E042`).
IDs are stored and compared in uppercase. The system auto-converts to uppercase on input.
IDs must be unique — checked via HashMap before insertion.
